﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate_Image : MonoBehaviour {

	private void OnMouseDown()
    {
        if (!Game_Controller.youwin)
            transform.Rotate(0f, 0f, 90f);
    }
}

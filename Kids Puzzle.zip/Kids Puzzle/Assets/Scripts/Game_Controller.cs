﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Game_Controller : MonoBehaviour {

    [SerializeField]
    private Transform[] Images;
    [SerializeField]
    private GameObject wintext;
    public static bool youwin;
    public Animator GameFinished;

	void Start () {
        wintext.SetActive(false);
        youwin = false;
		
	}
	
	// Update is called once per frame
	void Update () {
		if(Images[0].rotation.z == 0 &&
            Images[1].rotation.z == 0 &&
            Images[2].rotation.z == 0 &&
            Images[3].rotation.z == 0 &&
            Images[4].rotation.z == 0 &&
            Images[5].rotation.z == 0 &&
            Images[6].rotation.z == 0 &&
            Images[7].rotation.z == 0 
            )
        {
            youwin = true;
            wintext.SetActive(true);
            StartCoroutine(GameFinishedpanel());
        }
         
	}
    IEnumerator GameFinishedpanel()
    {
        yield return new WaitForSeconds(1f);
        GameFinished.Play("slideIn");
    }
    public void NextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
    public void LoadMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
